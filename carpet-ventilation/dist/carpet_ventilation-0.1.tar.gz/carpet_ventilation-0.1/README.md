# carpet-ventilation

A Python library for calculating carpet area and airflow ventilation of a house.

## Installation

You can install the library using pip:

```bash
pip install carpet-ventilation
